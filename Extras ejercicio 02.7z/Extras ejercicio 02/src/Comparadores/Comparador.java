package Comparadores;

import Entidad.Ficha;
import java.util.Comparator;

public class Comparador {

    public static Comparator <Ficha> compi = new Comparator<Ficha>() {
        @Override
        public int compare(Ficha t, Ficha t1) {
           return t.getLado1().compareTo(t1.getLado2());
        }
    };
}
