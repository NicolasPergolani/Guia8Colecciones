/*
Implementa un clase Ficha (de dominó) con su constructor y sus getters, con un toString() (que 
imprima el “seis-zero” como “6:0|” y con un método llamado “Ficha girarFicha()” que gire la 
ficha (el “6:0|” pasaría a ser “0:6|”). Implementa también el método “boolean esUnDoble()”. 
A) Ahora implementa con ArrayLists una clase que genere todas las fichas desde el doble 0 al 
doble MAX_NUM. Después, el programa, actuando como si fuera un robot jugando al solitario, 
empezará por tirar el doble más grande e irá tirando fichas (las jugadas tienen que ser legales) 
hasta que haya tirado todas sus fichas (de su “mano” a la “mesa) o ya no pueda tirar ninguna 
ficha más. Tu ejecución puede ser diferente de las de los ejemplos dependiendo de cómo lo 
implementes
 */
package Servicio;

import Entidad.Ficha;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class FichaServicio {

    ArrayList<Ficha> fichita = new ArrayList<Ficha>();
    ArrayList<Ficha> manito = new ArrayList<Ficha>();
    ArrayList<Ficha> mesita = new ArrayList<Ficha>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void fichas() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                Ficha f = new Ficha();
                if (i == 0) {
                    f.setLado1(i);
                    f.setLado2(j);
                    fichita.add(f);
                }
                if ((i == 1 && j > 0) || (i == 2 && j > 1) || (i == 3 && j > 2) || (i == 4 && j > 3) || (i == 5 && j > 4) || (i == 6 && j > 5)) {
                    f.setLado1(i);
                    f.setLado2(j);
                    fichita.add(f);
                }
            }
        }
        for (Ficha var : fichita) {
            System.out.print(var);
        }
        System.out.println("");
        System.out.println(fichita.size());
        System.out.println("..................");
    }

    public void girarFicha() {
        System.out.println("");
        int ladoA, ladoB;
        System.out.println("Elija que fecha quiere girar");
        ladoA = leer.nextInt();
        ladoB = leer.nextInt();

        for (Ficha var : fichita) {
            if (var.getLado1() == ladoA && var.getLado2() == ladoB) {
                var.setLado1(ladoB);
                var.setLado2(ladoA);
            }
        }
    }

    public void generarMano() {

        int[] vectormano = new int[7];

        for (int i = 0; i < 7; i++) {
            vectormano[i] = (int) (Math.random() * fichita.size());
            for (int j = 0; j < i; j++) {
                if (vectormano[i] == vectormano[j]) {
                    i--;
                }
            }
        }
        System.out.println("");
        for (int i = 0; i < 7; i++) {
            System.out.println(vectormano[i]);
        }
        int contador = 0;
        for (int i : vectormano) {
            manito.add(fichita.get(vectormano[contador]));
            contador++;
        }
        for (Ficha var : manito) {
            System.out.println(var);
        }

        fichita.removeAll(manito);
        int suma = 0;

        int maximo = -1;
        int masGrande = -1;
        while (!esunDoble()) {
            manito.add(fichita.get((int) Math.random() * fichita.size()));
            fichita.removeAll(manito);
        }
        for (Ficha var : manito) {
            if (var.getLado1() == var.getLado2()) {
                suma = (var.getLado1()) + (var.getLado2());
                if (maximo < suma) {
                    maximo = suma;
                    masGrande = manito.indexOf(var);
                }
            }

        }
        mesita.add(manito.get(masGrande));

        System.out.println(maximo);
        System.out.println("........");
        System.out.println(manito.get(masGrande));
        System.out.println("...............");
        manito.removeAll(mesita);

        System.out.println(fichita.size());
        System.out.println(manito.size());
        System.out.println(mesita.size());

        System.out.println("manito");
        for (Ficha var : manito) {
            System.out.print(var);
        }
        System.out.println("");
        System.out.println("fichita");
        for (Ficha var : fichita) {
            System.out.print(var);
        }
        System.out.println("");
    }

    public boolean esunDoble() {
        boolean esunDoble = true;
        int cont = 0;
        for (Ficha var : manito) {
            if (var.getLado1() == var.getLado2()) {
                cont++;
            }
        }
        if (cont > 0) {
            return true;
        } else {
            return false;
        }
    }

    public void jugadas() {
        System.out.println("Las fichas sobre la mesa son: ");
        for (Ficha var : mesita) {
            System.out.print("\n" + var);
        }
        int algo = 0, algomas = 0;

        for (int i = 0; i < manito.size(); i++) {
            if (manito.get(i).getLado1() == mesita.get(algo).getLado2()) {
                mesita.add(manito.get(i));
                manito.remove(i);
                algo++;
            }
        }

        for (int i = 0; i < manito.size(); i++) {
            if (mesita.get(0).getLado1() == manito.get(i).getLado2()) {
                mesita.add(0, manito.get(i));
                manito.remove(i);
                algomas++;
            }
        }
        System.out.println("");
        for (Ficha var : mesita) {
            System.out.print(var);
        }
        System.out.println("");
        System.out.println("------------");
        for (Ficha var : manito) {
            System.out.print(var);
        }
        System.out.println("");
    }

}
