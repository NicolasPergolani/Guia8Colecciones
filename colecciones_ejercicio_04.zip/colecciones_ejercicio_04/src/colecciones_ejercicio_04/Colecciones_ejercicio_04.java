

package colecciones_ejercicio_04;

//@author Facundo Cruz

import Entidad.Pelicula;
import Servicio.PeliculaService;
import java.util.ArrayList;


public class Colecciones_ejercicio_04 {

    public static void main(String[] args) {
        PeliculaService sv = new PeliculaService();
        ArrayList<Pelicula> lista = new ArrayList();
        sv.crearPelicula(lista);
        for (Pelicula aux : lista) {
            System.out.println(aux);
        }
    }

}
